#!/bin/sh
set -eu
# Run from the Petri repository root, preferably at the report's source revision.
probe_dir=.bench-artifacts/drift-silence-2026-09-24
export CARGO_TARGET_DIR="$PWD/.bench-artifacts/drift-silence-target"
export CARGO_BUILD_JOBS=4
export RAYON_NUM_THREADS=4
cargo test --offline --release --manifest-path "$probe_dir/Cargo.toml"
cargo build --offline --release --manifest-path "$probe_dir/Cargo.toml"
"$CARGO_TARGET_DIR/release/drift-silence-probe" > "$probe_dir/panel.ndjson" 2> "$probe_dir/run.log"
python3 "$probe_dir/analyze.py"
