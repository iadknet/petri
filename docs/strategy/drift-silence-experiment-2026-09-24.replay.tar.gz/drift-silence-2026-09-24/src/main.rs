use rand::{rngs::SmallRng, SeedableRng};
use serde_json::{json, Value};
use std::{
    collections::{BTreeMap, BTreeSet},
    error::Error,
    time::Instant,
};
use v3_core::{
    config::{resolve_config, FounderProfile, SimulationConfig},
    contracts::{NodeId, WorldAction},
    creature::{
        founder::{founder_genome, FOUNDER_GENOME_SIZE_UNITS},
        genome::{analysis::mesh_reachable_nodes, CreatureGenome},
    },
    mutation::{reachability::ParentExecuted, MutationEngine},
    neighborhood::{
        births, classify, drift, mesh_execution::indices_for_node_ids, Battery, EvalContext,
        Signature, Tally,
    },
};
const CHECKPOINTS: [u64; 5] = [0, 22, 250, 1000, 2000];
fn config() -> Result<SimulationConfig, Box<dyn Error>> {
    let patch = serde_json::from_str(&std::fs::read_to_string(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../experiments/worlds/orchards-in-grassland.json"
    ))?)?;
    Ok(resolve_config(&SimulationConfig::default(), patch)?)
}
fn all_noop(sig: &Signature) -> bool {
    sig.snapshots
        .iter()
        .chain(sig.sequences.iter().flatten())
        .flatten()
        .all(|a| matches!(a, WorldAction::NoOp))
}
fn tally_json(t: Tally) -> Value {
    json!({"trials":t.trials,"silent":t.silent,"changed":t.changed,"dead":t.dead,"skipped":t.skipped})
}
fn advance(
    g: &mut CreatureGenome,
    rng: &mut SmallRng,
    ids: &mut BTreeSet<NodeId>,
    depth: u64,
    battery: &Battery,
    c: &SimulationConfig,
) {
    if depth % drift::EXECUTED_REFRESH_INTERVAL == 0 {
        *ids = battery.executed_node_ids(g, &c.runtime, c.shared_memory.decay_rate);
    }
    let reachable = mesh_reachable_nodes(g);
    let executed = indices_for_node_ids(g, ids);
    MutationEngine::apply_mutations_on_units(
        g,
        FOUNDER_GENOME_SIZE_UNITS,
        &c.mutation,
        &reachable,
        ParentExecuted::Indices(&executed),
        rng,
        c.world.food.types.len(),
    );
}
fn controls(
    g: &CreatureGenome,
    b: &Battery,
    c: &SimulationConfig,
    depth: u64,
    lineage: u64,
    base: &Signature,
    contributing: &BTreeSet<NodeId>,
) {
    let executed = b.executed_indices(g, &c.runtime, c.shared_memory.decay_rate);
    let contributing_indices = indices_for_node_ids(g, contributing);
    let reachable = mesh_reachable_nodes(g);
    for arm in ["executed_0.9", "executed_0.0", "contributing_oracle_1.0"] {
        let mut mutation = c.mutation.clone();
        mutation.per_unit_rate = 1.0;
        mutation.executed_bias = match arm {
            "executed_0.9" => 0.9,
            "executed_0.0" => 0.0,
            _ => 1.0,
        };
        let target_indices = if arm == "contributing_oracle_1.0" {
            &contributing_indices
        } else {
            &executed
        };
        let mut tallies: BTreeMap<String, Tally> = BTreeMap::new();
        let mut operators: BTreeMap<String, Tally> = BTreeMap::new();
        let mut unchanged_genome = 0;
        for trial in 0..100u64 {
            let mut child = g.clone();
            let mut rng =
                SmallRng::seed_from_u64(30_000_000 + depth * 10_000 + lineage * 100 + trial);
            let s = MutationEngine::apply_mutations_on_units(
                &mut child,
                1,
                &mutation,
                &reachable,
                ParentExecuted::Indices(target_indices),
                &mut rng,
                c.world.food.types.len(),
            );
            assert_eq!(s.attempted_events, 1);
            assert_eq!(s.events.len(), 1);
            let event = &s.events[0];
            let bucket = match event.target {
                Some(id) if contributing.contains(&id) => "contributing",
                Some(id) if executed.iter().any(|i| g.nodes[*i].node_id == id) => {
                    "executed_noncontributing"
                }
                Some(_) => "unexecuted",
                None => "no_node_target",
            };
            let classification = if s.applied_events == 0 {
                None
            } else {
                if child == *g {
                    unchanged_genome += 1;
                }
                Some(classify(
                    &base,
                    &b.signature(&child, &c.runtime, c.shared_memory.decay_rate),
                ))
            };
            let op = format!("{:?}/{:?}", event.domain, event.operator);
            for entry in [
                tallies.entry(bucket.to_string()).or_default(),
                operators.entry(op).or_default(),
            ] {
                *entry = match classification {
                    Some(x) => entry.record(x),
                    None => entry.skip(),
                };
            }
        }
        let convert = |m: BTreeMap<String, Tally>| {
            m.into_iter()
                .map(|(k, t)| (k, tally_json(t)))
                .collect::<BTreeMap<_, _>>()
        };
        println!(
            "{}",
            json!({"kind":"control", "depth":depth,"lineage":lineage,"arm":arm,"applied_but_equal_genome":unchanged_genome,"targets":convert(tallies),"operators":convert(operators)})
        );
    }
}
fn main() -> Result<(), Box<dyn Error>> {
    let started = Instant::now();
    let c = config()?;
    let b = Battery::generate(c.world.food.types.len());
    let context = EvalContext::from_config(&c);
    println!(
        "{}",
        json!({"kind":"metadata","config_digest":v3_core::config::config_digest(&c),"food_types":context.food_type_count,"lineages":20,"checkpoints":CHECKPOINTS})
    );
    for lineage in 0..20u64 {
        let mut g = founder_genome(FounderProfile::V3Alpha1);
        let mut rng = SmallRng::seed_from_u64(drift::WALK_SEED_BASE + lineage);
        let mut ids = BTreeSet::new();
        let mut depth = 0;
        for checkpoint in CHECKPOINTS {
            while depth < checkpoint {
                if started.elapsed().as_secs() >= 300 {
                    return Err("five-minute experiment cap exceeded".into());
                }
                advance(&mut g, &mut rng, &mut ids, depth, &b, &c);
                depth += 1;
            }
            let base = b.signature(&g, &c.runtime, c.shared_memory.decay_rate);
            let sets = b.mesh_execution_sets(&g, &c.runtime, c.shared_memory.decay_rate);
            let births = births::per_birth_result_on_units(
                &g,
                FOUNDER_GENOME_SIZE_UNITS,
                &base,
                &b,
                &c.mutation,
                &context,
                100,
                drift::BIRTH_OFFSET_BASE + drift::BIRTH_LINEAGE_MULTIPLIER * (lineage + 1) + depth,
            );
            let unique: BTreeSet<_> = base
                .snapshots
                .iter()
                .chain(base.sequences.iter().flatten())
                .map(|q| format!("{q:?}"))
                .collect();
            println!(
                "{}",
                json!({"kind":"checkpoint","lineage":lineage,"depth":depth,"all_noop":all_noop(&base),"unique_queues":unique.len(),"units":g.genome_size(),"nodes":g.nodes.len(),"reachable":sets.reading.reachable_node_count,"executed":sets.executed.len(),"contributing":sets.contributing.len(),"pass_cap_hits":sets.reading.pass_cap_hits,"births":tally_json(births.any_events),"zero":births.zero_event_births})
            );
            if depth == 0 || depth == 2000 {
                controls(&g, &b, &c, depth, lineage, &base, &sets.contributing);
            }
            if depth == 2000 {
                std::fs::write(
                    format!(".bench-artifacts/drift-silence-2026-09-24/genome-{lineage}.json"),
                    serde_json::to_vec(&g)?,
                )?;
            }
        }
    }
    eprintln!("elapsed_seconds={:.3}", started.elapsed().as_secs_f64());
    Ok(())
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn replay_matches_native_walk_without_observation_rng_interference() {
        let c = config().unwrap();
        let b = Battery::generate(c.world.food.types.len());
        let founder = founder_genome(FounderProfile::V3Alpha1);
        let native = drift::observe(
            &founder,
            &b,
            &c.mutation,
            &EvalContext::from_config(&c),
            drift::DriftSizes {
                lineages: 1,
                birth_lineages: 1,
                births: 100,
                checkpoints: &[0, 22],
            },
        );
        let mut g = founder.clone();
        let mut rng = SmallRng::seed_from_u64(drift::WALK_SEED_BASE);
        let mut ids = BTreeSet::new();
        for depth in 0..22 {
            advance(&mut g, &mut rng, &mut ids, depth, &b, &c);
        }
        let base = b.signature(&g, &c.runtime, c.shared_memory.decay_rate);
        let actual = births::per_birth_result_on_units(
            &g,
            FOUNDER_GENOME_SIZE_UNITS,
            &base,
            &b,
            &c.mutation,
            &EvalContext::from_config(&c),
            100,
            drift::BIRTH_OFFSET_BASE + drift::BIRTH_LINEAGE_MULTIPLIER + 22,
        );
        assert_eq!(actual, native.checkpoints[1].births);
        assert_eq!(
            classify(&base, &base).class,
            v3_core::neighborhood::Class::Silent
        );
        assert!(!all_noop(&b.signature(
            &founder,
            &c.runtime,
            c.shared_memory.decay_rate
        )));
    }
}
