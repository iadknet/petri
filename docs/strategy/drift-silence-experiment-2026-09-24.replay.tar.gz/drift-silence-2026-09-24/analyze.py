import json,collections,hashlib,re
from pathlib import Path
root=Path(__file__).resolve().parents[2]
p=Path(__file__).resolve().parent
rows=[json.loads(s) for s in (p/'panel.ndjson').read_text().splitlines()]
parents={(r['depth'],r['lineage']):r for r in rows if r['kind']=='checkpoint'}
assert len(parents)==100
stored=json.loads((root/'docs/progress/features/t11-f24-stable-parent-membership-during-mutation-goal.json').read_text())['deterministic']['goal_indicators']['cases'][0]['drift_depth']['readings']
keys=['trials','silent','changed','dead','skipped']
def add(ts):return dict(sum((collections.Counter(t) for t in ts),collections.Counter()))
checkpoints=[]
for depth in [0,22,250,1000,2000]:
 rs=[r for r in parents.values() if r['depth']==depth]
 sums={k:sum(r['births'][k] for r in rs) for k in keys}
 old=next(r for r in stored if r['depth']==depth)
 for k in ['silent','changed','dead']:assert sums[k]==old['births']['any_events'][k]
 assert sum(r['zero'] for r in rs)+sums['trials']==2000
 assert sums['trials']==sum(sums[k] for k in ['silent','changed','dead'])
 groups={}
 for noop in [False,True]:
  sub=[r for r in rs if r['all_noop']==noop]
  groups['all_noop' if noop else 'has_non_noop']={'parents':len(sub),'births':{k:sum(r['births'][k] for r in sub) for k in keys}}
 checkpoints.append({'depth':depth,'parents':20,'all_noop_parents':sum(r['all_noop'] for r in rs),'one_unique_queue_parents':sum(r['unique_queues']==1 for r in rs),'mean_nodes':sum(r['nodes'] for r in rs)/20,'mean_executed':sum(r['executed'] for r in rs)/20,'mean_contributing':sum(r['contributing'] for r in rs)/20,'zero_contributing_parents':sum(r['contributing']==0 for r in rs),'births':sums,'parent_strata':groups})
controls=[]
for depth in [0,2000]:
 for arm in ['executed_0.9','executed_0.0','contributing_oracle_1.0']:
  rs=[r for r in rows if r['kind']=='control' and r['depth']==depth and r['arm']==arm]
  assert len(rs)==20
  total={k:sum(t[k] for r in rs for t in r['targets'].values()) for k in keys}
  assert total['trials']==2000 and total['trials']==sum(total[k] for k in ['silent','changed','dead','skipped'])
  by_target={target:{k:sum(r['targets'].get(target,{}).get(k,0) for r in rs) for k in keys} for target in sorted({k for r in rs for k in r['targets']})}
  by_op={op:{k:sum(r['operators'].get(op,{}).get(k,0) for r in rs) for k in keys} for op in sorted({k for r in rs for k in r['operators']})}
  controls.append({'depth':depth,'arm':arm,'totals':total,'first_parent_target_class':by_target,'operators':by_op,'applied_but_equal_genome':sum(r['applied_but_equal_genome'] for r in rs)})
assert all(next(r for r in controls if r['depth']==0 and r['arm']==arm)['totals']==controls[0]['totals'] for arm in ['executed_0.0','contributing_oracle_1.0'])
result={'source':'df35975f805e11324b196535d8d391569270f07b','metadata':rows[0],'wall_seconds':float(re.search(r'elapsed_seconds=([0-9.]+)',(p/'run.log').read_text()).group(1)),'stored_checkpoint_tallies_match':True,'checkpoint_births':10000,'control_proposals':12000,'checkpoints':checkpoints,'controls':controls,'limitations':['Single current Orchards configuration; first20 fixed chart lineages, not fresh independently sampled populations.','Founder controls repeat one genotype with separate seed streams.','Actionless and contributing are finite-battery properties, not ecological viability or usefulness.','First selected node is not a causal attribution to all modified tissue.','Contributing-set arm uses an observation oracle and normal fallback, not a production candidate or upper bound.','No selected-genome, expanded-battery, multistep discovery, or reproductive-benefit comparison.'],'panel_sha256':hashlib.sha256((p/'panel.ndjson').read_bytes()).hexdigest()}
(p/'results.json').write_text(json.dumps(result,indent=2)+'\n')
(root/'docs/strategy/drift-silence-experiment-2026-09-24.results.json').write_text(json.dumps(result,indent=2)+'\n')
print('All checkpoint, accounting, and founder control checks passed. Wrote results.')
